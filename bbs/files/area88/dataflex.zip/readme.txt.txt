
Copy the Modem.inf file into the \WINNT\SYSTEM32\RAS directory.

The is not an officially supported file.